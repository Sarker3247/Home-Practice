<h1>APPLY</h1>



<form method=get action=apply.php>

	DATE_OF_TRAVEL: <input type=text name=DATE_OF_TRAVEL> <br>

	<p>

	REASON_OF_TRAVEL: <input type=text name=REASON_OF_TRAVEL> <br>

	<p>

	<input type=submit value=Insert>

</form>