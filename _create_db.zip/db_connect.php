<?php

	// Defining Constants
	define( 'HOST', 'localhost' );
	define( 'DB', 'TRAFFIC_POLICE_DB' );
	define( 'USER', 'root' );
	define( 'PASS', '' );
?>